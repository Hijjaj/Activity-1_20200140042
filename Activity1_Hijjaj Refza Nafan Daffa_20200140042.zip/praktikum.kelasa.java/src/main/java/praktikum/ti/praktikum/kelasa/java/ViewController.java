/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package praktikum.ti.praktikum.kelasa.java;

import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author Hijjaj
 */
@Controller
public class ViewController {
    @RequestMapping("/lihatdata")
    public String lihatdata(HttpServletRequest data, Model model){
        String Nama_Buah = data.getParameter("Nama");
        String jb = data.getParameter("Jumlah Beli");
        String hp = data.getParameter("Harga Perkilo");
        
        model.addAttribute("Nama", Nama_Buah);
       
        model.addAttribute("Jumlah Beli", jb);
        model.addAttribute("Harga Perkilo", hp);
        
        return "ControllerJava";
    }
}
