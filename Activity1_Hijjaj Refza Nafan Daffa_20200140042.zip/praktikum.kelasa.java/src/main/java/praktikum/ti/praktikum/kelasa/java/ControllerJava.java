/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package praktikum.ti.praktikum.kelasa.java;

import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import praktikum.ti.praktikum.kelasa.java.ViewController;
/**
 *
 * @author Hijjaj
 */
@Controller
public class ControllerJava {
    @RequestMapping("/kasir")
    public String getnama(HttpServletRequest data,Model kurir){
        String Nama_Buah = "";
        kurir.addAttribute("ninja", Nama_Buah);
        
        return "Hijjaj";
        
    }
    public String getharga(HttpServletRequest data,Model kurir){
        ViewController VC = new ViewController();
        
        String jb = data.getParameter("Jumlah Beli");
        double jumlahbeli = Double.parseDouble(jb);
        String hp = data.getParameter("Harga Perkilo");
        double hargaperkilo = Double.parseDouble(hp);
        double hitung = 0.0;
        double harga = 0.0;
        
        hitung = (jumlahbeli * hargaperkilo);
        if ((hitung > 16000)&&(hitung < 25000))
            harga = hitung*10/100;
        if (hitung > 25000)
            harga = hitung*25/100;
        kurir.addAttribute("jne", harga);
        kurir.addAttribute("jne2", jumlahbeli);
        kurir.addAttribute("jne3", hargaperkilo);
        kurir.addAttribute("jne4", hitung);
        return "Hijjaj";
    }
    
    
}
